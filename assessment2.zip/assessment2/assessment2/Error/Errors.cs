﻿using System.Text.Json.Serialization;

namespace Assessment2.Error
{
    public class Errors
    {
        [JsonIgnore]
        public int id { get; set; }
        public string Source { get; set; }

        public string Description { get; set; }
    }
}
