﻿namespace Assessment2.Error
{
    public class Correlation
    {
        public Guid CorrelationId { get; set; }

        public List<Errors> Errors { get; set; }
    }
}
