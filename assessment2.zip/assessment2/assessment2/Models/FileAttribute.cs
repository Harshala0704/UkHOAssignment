﻿using System.Text.Json.Serialization;

namespace assessment2.Models
{
    public class FileAttribute
    {
        [JsonIgnore]
        public int Id { get; set; }
        public string key { get; set; }

        public string value { get; set; }


        [JsonIgnore]
        public int FileId { get; set; }

       




    }
}
