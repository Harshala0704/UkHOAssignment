﻿using System.Text.Json.Serialization;

namespace assessment2.Models
{
    public class ReadUsers
    {
       
        [JsonIgnore]

        public int Id { get; set; }

        public string UserName{ get; set; }

        [JsonIgnore]
        public Guid BatchId { get; set; }
    }
}
