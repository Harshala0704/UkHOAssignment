﻿using System.Text.Json.Serialization;

namespace assessment2.Models
{
    public class File
    {
        [JsonIgnore]
        public int Id { get; set; }
        public string FileName { get; set; }
        public int FileSize { get; set; }
        public string MimeType { get; set; }
        public string Hash { get; set; }

        public List<FileAttribute> FileAttribute { get; set; }

        [JsonIgnore]
        public Guid BatchId { get; set; }
    }
}
