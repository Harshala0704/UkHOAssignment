﻿using System.Text.Json.Serialization;

namespace assessment2.Models
{
    public class Batch
    {
       // [JsonIgnore]
        public Guid BatchId { get; set; }

        public BusinessUnit BusinessUnit { get; set; }

        public List <ReadUsers> ReadUsers { get; set; }

        public List <ReadGroups> ReadGroups { get; set; }
   
        public List <Attribute> Attribute { get; set; }

        public DateTime ExpiryDate { get; set; }

        public List <File> File { get; set; }

       


    }
}
