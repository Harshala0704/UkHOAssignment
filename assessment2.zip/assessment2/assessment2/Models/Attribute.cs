﻿using System.Text.Json.Serialization;

namespace assessment2.Models
{
    public class Attribute
    {
        [JsonIgnore]
        public int Id { get; set; }
        public string key { get; set; }

        public string value { get; set; }

        [JsonIgnore]
        public Guid BatchId { get; set; }

    }
}
