﻿using System.Text.Json.Serialization;

namespace assessment2.Models
{
    public class BusinessUnit
    {
        [JsonIgnore]
        public int Id { get; set; }
        public string Description { get; set; }

        [JsonIgnore]

        public Guid BatchId { get; set; }
    }
}
