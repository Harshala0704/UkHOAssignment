﻿using System.Text.Json.Serialization;

namespace assessment2.Models
{
    public class ReadGroups
    {
        [JsonIgnore]
        public int Id { get; set; }
        public string GroupName { get; set; }
        
        [JsonIgnore]
        public Guid BatchId { get; set; }
    }
}
