﻿using assessment2.Data;
using assessment2.Models;
using assessment2.Validation;
using Assessment2.Error;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Swashbuckle.AspNetCore.Annotations;

namespace assessment2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BatchController : ControllerBase
    {

        AppDbContext appDbContext = new AppDbContext();





        [HttpGet]
        public IEnumerable<Batch> Get()
        {
            return appDbContext.Batches.ToList();



        }



        [HttpPost]
        [SwaggerOperation(Summary = "Create a new Batch to upload files into.")]
        public ActionResult Save(Batch batch1)
        {
            // appDbContext.BusinessUnit.Where(project => project.Description.Equals(name)).FirstOrDefault();

            if(batch1.ReadGroups != null)
            {
                CustomValidator custom = new CustomValidator();
                appDbContext.Batches.Add(batch1);
                appDbContext.SaveChanges();
                return new ObjectResult(new { BatchId = batch1.BatchId })
                {
                    StatusCode = StatusCodes.Status201Created
                };

            }
            else
            {
                Correlation result = CreateError();
                // throw new Exception("Error");
                ModelState.AddModelError("Error", "result");
                 return BadRequest(result);
            }
           
        }

       
      private static Correlation CreateError()
        {
            Correlation result = new Correlation();
            Errors e = new Errors();
            result.CorrelationId = Guid.NewGuid();
            e.Source = "abc";
            e.Description = "pqr";
            result.Errors.Add(e);
            return result;
        }






        //var batchid = new  { Correlationalid = "", errors =['source': "", 'Description': ""] };
        // appDbContext.batchIds.Add(batchid);
        // appDbContext.SaveChanges();
        // return Ok(new { batchid = id });
        // var data = new { guid = "id" };

    
        [HttpGet("{id}", Name = "Get")]
        [SwaggerOperation(Summary = "Get details of the batch including links to all the files in the ")]
        public async Task<ActionResult> GetBatchAsync(Guid id)
        {
            var res= await appDbContext.Batches.Include(x => x.BusinessUnit).Include(x => x.ReadUsers).Include(x => x.ReadGroups).Include(x => x.Attribute).Include(x => x.File).ThenInclude(x => x.FileAttribute).FirstOrDefaultAsync(x => x.BatchId == id);
           if (res == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(res);
            }
        }











    }



}

