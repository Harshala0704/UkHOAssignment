﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Assessment2.Migrations
{
    public partial class v4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileAttributes_File_FileId",
                table: "FileAttributes");

            migrationBuilder.AlterColumn<int>(
                name: "FileId",
                table: "FileAttributes",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_FileAttributes_File_FileId",
                table: "FileAttributes",
                column: "FileId",
                principalTable: "File",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileAttributes_File_FileId",
                table: "FileAttributes");

            migrationBuilder.AlterColumn<int>(
                name: "FileId",
                table: "FileAttributes",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_FileAttributes_File_FileId",
                table: "FileAttributes",
                column: "FileId",
                principalTable: "File",
                principalColumn: "Id");
        }
    }
}
