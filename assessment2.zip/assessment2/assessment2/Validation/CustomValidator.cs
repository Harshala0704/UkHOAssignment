﻿using assessment2.Models;
using Assessment2.Error;
using FluentValidation;

namespace assessment2.Validation
{
    public class CustomValidator : AbstractValidator<Batch>
    {

        public CustomValidator()
        {

           RuleFor(x => x.BusinessUnit.Description).NotNull().NotEmpty()
                .WithMessage("Description is mandatory")
                .MinimumLength(4)
                .WithMessage("Description is  needs at least 4 characters");


            // RuleFor(x => x.Attribute).NotNull().NotEmpty().WithMessage("Attribute is mandatory");

            RuleForEach(p => p.Attribute).ChildRules(child =>
            {
              
                child.RuleFor(x => x.key).NotEmpty().WithMessage("required").NotNull();

            });


            RuleForEach(p => p.Attribute).ChildRules(child =>
            {
                child.RuleFor(x => x.value).NotEmpty().WithMessage("required").NotNull();

            });

            RuleForEach(p => p.ReadUsers).ChildRules(child =>
            {
                child.RuleFor(x => x.UserName).NotEmpty().WithMessage("required").NotNull();

            });


            RuleForEach(p => p.ReadGroups).ChildRules(child =>
            {
                child.RuleFor(x => x.GroupName).NotEmpty().WithMessage("required").NotNull();

            });


            RuleForEach(p => p.File).ChildRules(child =>
            {
                child.RuleFor(x => x.FileName).NotEmpty().WithMessage("FileName is needs at least 7 characters").NotNull();

            });

            RuleForEach(p => p.File).ChildRules(child =>
            {
                child.RuleFor(x => x.FileSize).NotEmpty().WithMessage("File size is larger than allowed").NotNull().LessThanOrEqualTo(100);

            });

            RuleForEach(p => p.File).ChildRules(child =>
            {
                child.RuleFor(x => x.MimeType).NotEmpty().WithMessage("MimeType is needs at least 3 characters").NotNull();

            });

            RuleForEach(p => p.File).ChildRules(child =>
            {
                child.RuleFor(x => x.Hash).NotEmpty().WithMessage("Hash is needs at least 5 characters").NotNull();

            });
















        }




        /* public class FileValidator : AbstractValidator<Models.File>
         {

             public FileValidator()
             {
                 RuleFor(x => x.FileName).NotEmpty()
                    .WithMessage("FileName is mandatory")
                    .MinimumLength(7)
                    .WithMessage("FileName is needs at least 7 characters");

                 RuleFor(x => x.FileSize).NotNull().LessThanOrEqualTo(100)
                    .WithMessage("File size is larger than allowed");


                 RuleFor(x => x.MimeType).NotEmpty()
                    .WithMessage("MimeType is mandatory")
                    .MinimumLength(3)
                    .WithMessage("MimeType is needs at least 3 characters");


                 RuleFor(x => x.Hash).NotEmpty()
                    .WithMessage("Hash is mandatory")
                    .MinimumLength(5)
                    .WithMessage("Hash is needs at least 5 characters");


             }

             public class FileAttributeValidator: AbstractValidator<Models.FileAttribute>
             {
                 public FileAttributeValidator()
                 {

                     RuleFor(x => x.key).NotEmpty()
                    .WithMessage("Key is mandatory")
                    .MinimumLength(4)
                    .WithMessage("Key is needs at least 4 characters");

                     RuleFor(x => x.value).NotEmpty()
                        .WithMessage("Value is mandatory")
                        .MinimumLength(5)
                        .WithMessage("Value is needs at least 4 characters");

                 }

                 public class ReadUsers : AbstractValidator<Models.ReadUsers>
                 {
                     public ReadUsers()
                     {
                         RuleFor(x => x.UserName).NotEmpty()
                         .WithMessage("UserName is mandatory")
                         .MinimumLength(7)
                         .WithMessage("Username is needs at least 7 characters");



                     }


                     public class ReadGroups : AbstractValidator<Models.ReadGroups>
                     {
                         public ReadGroups()
                         {

                             RuleFor(x => x.GroupName).NotEmpty()
                             .WithMessage("GroupName is mandatory")
                             .MinimumLength(7)
                             .WithMessage("GroupName is needs at least 7 characters");


                         }
                     }
                 }
     */






    }
}


 
