﻿using assessment2.Models;
using Assessment2.Error;
using Microsoft.EntityFrameworkCore;

namespace assessment2.Data
{
    public class AppDbContext : DbContext
    {



        public AppDbContext()
        {
        }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {




        }

       // public DbSet<batch> Batchs { get; set; }

        public DbSet<Batch> Batches { get; set; }

        public DbSet<BusinessUnit> BusinessUnit { get; set; }

        public DbSet<Models.Attribute> attributes { get; set; } 
        
        public DbSet<Models.File> File { get; set; }

        public DbSet<ReadUsers> ReadUsers { get; set; }


        public DbSet<ReadGroups> ReadGroups { get; set; }

        public DbSet<FileAttribute> FileAttributes { get; set; }


        public DbSet<Correlation> Correlations { get; set; }


        public DbSet<Errors> Errors { get; set; }










        protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptionsBuilder)
        {

            dbContextOptionsBuilder.UseSqlServer("server=.;user id=sa;password=M8$tek12;database=T5;TrustServerCertificate=true");

        }

    }
}

  
